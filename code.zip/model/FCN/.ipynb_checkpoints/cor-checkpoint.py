import torch
import torch.nn as nn
import torch.nn.functional as F
import itertools

class Correlation(torch.nn.Module):
    def __init__(self):
        super(Correlation, self).__init__()

    def forward(self, x):
        # 获取张量的维度
        N, C, H, W = x.size()

        x_reshaped = x.view(N, C, -1)  # 形状: (N, C, H*W)
        x_mean = x_reshaped.mean(dim=2, keepdim=True)  # 平均值 (N, C, 1)
        x_centered = x_reshaped - x_mean  # 中心化 (N, C, H*W)
        x_norm = torch.norm(x_centered, dim=2, keepdim=True)  # 归一化因子 (N, C, 1)
        x_normalized = x_centered / (x_norm + 1e-8)  # 归一化 (N, C, H*W)

        # 计算皮尔逊相关系数
        correlation_matrix = torch.bmm(x_normalized, x_normalized.transpose(1, 2))  # (N, C, C)

        # 对角线上的值即为每个通道与自身的相关系数，将其置为0
        for i in range(C):
            correlation_matrix[:, i, i] = 0

        # 取绝对值并计算总和，然后除以通道数的组合数以得到平均值
        absolute_correlation = torch.abs(correlation_matrix)
        total_correlation = absolute_correlation.sum()
        num_combinations = len(list(itertools.combinations(range(C), 2)))  # 通道数的组合数
        average_correlation = total_correlation / num_combinations / 2 / N

        return average_correlation
    
class FCNBlock(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(FCNBlock, self).__init__()
        self.block = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(),
            nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU()
        )
    
    def forward(self, x):
        return self.block(x)

class Model(nn.Module):
    def __init__(self, in_features, out_features, init_features, factor):
        super(Model, self).__init__()
        
        features = init_features
        
        # 编码器部分
        self.encode_layer1 = FCNBlock(in_features, features)
        self.encode_layer2 = FCNBlock(features, features * 2)
        self.encode_layer3 = FCNBlock(features * 2, features * 4)
        self.encode_layer4 = FCNBlock(features * 4, features * 8)
        self.encode_layer5 = FCNBlock(features * 8, features * 16) 
        
        # 最大池化层
        self.pool = nn.MaxPool2d(kernel_size=2, stride=2)
        
        # 减少通道
        self.score_pool3 = nn.Conv2d(features * 4, out_features, kernel_size=1)
        self.score_pool4 = nn.Conv2d(features * 8, out_features, kernel_size=1)
        self.score_pool5 = nn.Conv2d(features * 16, out_features, kernel_size=1)
        
        # 解码器部分
        self.upsample2 = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)
        self.upsample4 = nn.Upsample(scale_factor=4, mode='bilinear', align_corners=True)
        self.upsample8 = nn.Upsample(scale_factor=8, mode='bilinear', align_corners=True)
        
        self.sigmoid = nn.Sigmoid()

        self.correlation_module = Correlation()
        
        self.weight_layer = nn.Sequential(
            nn.Conv2d(5, 5 // factor, kernel_size=1, padding=0, stride=1),  
            nn.ReLU(),
            nn.Conv2d(5 // factor, 5, kernel_size=1, padding=0, stride=1),
            nn.Sigmoid()
        )

    def forward(self, x, inference=False):
        
        enc1 = self.encode_layer1(x)
        enc1_pool = self.pool(enc1)
        
        enc2 = self.encode_layer2(enc1_pool)
        enc2_pool = self.pool(enc2)
        
        enc3 = self.encode_layer3(enc2_pool)
        enc3_pool = self.pool(enc3)
        
        enc4 = self.encode_layer4(enc3_pool)
        enc4_pool = self.pool(enc4)
        
        enc5 = self.encode_layer5(enc4_pool)
        enc5_pool = self.pool(enc5)
        
        score3 = self.score_pool3(enc3_pool)
        score4 = self.score_pool4(enc4_pool)
        score5 = self.score_pool5(enc5_pool)

        out = score3 + self.upsample2(score4) + self.upsample4(score5)
        out = self.upsample8(out)
        
        out = self.sigmoid(out)
        
        if not inference:  # 如果非推理模式，执行以下计算
            cor1 = self.correlation_module(enc1_pool)
            cor2 = self.correlation_module(enc2_pool)
            cor3 = self.correlation_module(enc3_pool)
            cor4 = self.correlation_module(enc4_pool)
            cor5 = self.correlation_module(enc5_pool)
            cor_scores = torch.stack([cor1, cor2, cor3, cor4, cor5], dim=0)
            cor_scores = cor_scores.unsqueeze(-1).unsqueeze(-1).unsqueeze(0)

            weight_params= self.weight_layer(cor_scores)
            cor = torch.sum(weight_params * cor_scores, dim=1)
            
            return out, cor, cor1, cor2, cor3, cor4, cor5  # 在非推理模式返回相应计算结果

        return out  # 在推理模式下，只返回 out

'''测试代码
input_tensor = torch.randn(1, 3, 224, 224)
model = FCN8s(in_features=3, out_features=1, init_features=64)
output = model(input_tensor)
print(output.shape)
'''