import torch
import torch.nn as nn
import torch.nn.functional as F

class BCELoss(nn.Module):
    def __init__(self):
        super(BCELoss, self).__init__()

    def forward(self, y_pred, y_true):
        # 二进制交叉熵损失（注意：不应用Sigmoid函数）
        bce_loss = F.binary_cross_entropy(y_pred, y_true)

        return bce_loss