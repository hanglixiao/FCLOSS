import os
from PIL import Image

# 通用切片函数
def slice_image(image_path, slice_folder, slice_width, slice_height, extension=".jpg"):
    with Image.open(image_path) as img:
        width, height = img.size
        slices_count = 0
        # 遍历整个图像并进行切片
        for i in range(height // slice_height):
            for j in range(width // slice_width):
                box = (j * slice_width, i * slice_height, (j+1) * slice_width, (i+1) * slice_height)
                slice_img = img.crop(box)
                # 生成切片文件路径
                slice_path = os.path.join(slice_folder, f"{os.path.splitext(os.path.basename(image_path))[0]}-{i}-{j}{extension}")
                slice_img.save(slice_path)
                slices_count += 1
        
        return slices_count

# 切片操作封装
def process_images(image_folder, slice_folder, slice_width, slice_height, extension=".jpg"):
    os.makedirs(slice_folder, exist_ok=True)  # 创建切片存放文件夹
    images_slices_count = {}
    for image_file in os.listdir(image_folder):
        if image_file.endswith(extension):
            image_path = os.path.join(image_folder, image_file)
            slices_count = slice_image(image_path, slice_folder, slice_width, slice_height, extension=extension)
            images_slices_count[image_file] = slices_count

    print(images_slices_count)
    print(f"总切片数: {sum(images_slices_count.values())}")
    
    
'''
# 切割图像
images_folder = 'crack62/images/'
slice_folder = 'processing/divided/images/'
slice_width = 
slice_height = 
process_images(images_folder, slice_folder, slice_width, slice_height, extension=".jpg")

# 切割标签
labels_folder = 'crack62/labels/'
slice_folder = 'processing/divided/labels/'
process_images(labels_folder, slice_folder, slice_width, slice_height, extension=".png")
'''


import os
import shutil
from PIL import Image

# 移动有裂缝的图像和标签
def move_cracked_images_and_labels(labels_path, images_path, positive_labels_path, positive_images_path, crack_threshold=0.005, total_pixels=256*256):
    # 创建目标文件夹
    os.makedirs(positive_labels_path, exist_ok=True)
    os.makedirs(positive_images_path, exist_ok=True)

    # 获取有裂缝的文件
    cracked_files = []

    for file in os.listdir(labels_path):
        image_path = os.path.join(labels_path, file)
        image = Image.open(image_path)
        image = image.convert('L')  # 转为灰度图像
        pixel_values = list(image.getdata())
        count = sum(1 for pixel in pixel_values if pixel == 255)
        ratio = count / total_pixels
        # 判断裂缝占比
        if ratio >= crack_threshold:
            cracked_files.append(file)

    # 移动有裂缝的文件
    for file in cracked_files:
        # 移动标签文件
        shutil.move(os.path.join(labels_path, file), os.path.join(positive_labels_path, file))
        # 移动图像文件
        filename, ext = os.path.splitext(file)
        image_file = f"{filename}.jpg"  
        shutil.move(os.path.join(images_path, image_file), os.path.join(positive_images_path, image_file))

    print(f"已将 {len(cracked_files)} 张有裂缝的图像和标签移动到 {positive_labels_path}")
    print(f"已将 {len(cracked_files)} 张有裂缝的图像和标签移动到 {positive_images_path}")
    
    
'''
# 设置路径
labels_path = 'processing/divided/labels/'
images_path = 'processing/divided/images/'
positive_labels_path = 'processing/positive/labels/'
positive_images_path = 'processing/positive/images/'
crack_threshold=0.005
total_pixels=256*256

# 调用函数
move_cracked_images_and_labels(labels_path, images_path, positive_labels_path, positive_images_path, crack_threshold, total_pixels)
'''


import os
import matplotlib.pyplot as plt

def display_images_and_labels(image_folder, label_folder):
    """
    显示图像和对应标签的函数。
    
    参数:
    - image_folder: 存放图像的文件夹路径
    - label_folder: 存放标签的文件夹路径
    """
    # 获取图像文件夹中的所有图像文件路径
    image_paths = [os.path.join(image_folder, filename) for filename in os.listdir(image_folder) if filename.endswith('.jpg')]

    # 遍历图像文件并显示它们以及对应的标签图像
    for image_path in image_paths:
        file = os.path.basename(image_path)
        image = plt.imread(image_path)
        
        # 获取文件名并构建标签文件路径
        base_filename = os.path.splitext(file)[0]
        label_filename = base_filename + '.png'  # 假设标签文件的扩展名是.png
        label_path = os.path.join(label_folder, label_filename)
        
        # 检查标签文件是否存在
        if os.path.exists(label_path):
            label = plt.imread(label_path)
            
            # 检查图像和标签的尺寸是否匹配
            if image.shape[:2] == label.shape[:2]:
                # 创建一个新的图形窗口以显示图像和标签
                plt.figure(figsize=(12, 5))  # 您可以根据需要调整图像大小

                # 在左侧子图上绘制图像
                plt.subplot(121)
                plt.imshow(image)
                plt.title(f"Image: {base_filename}")

                # 在右侧子图上绘制标签使用灰度色彩图
                plt.subplot(122)
                plt.imshow(label, cmap='gray')
                plt.title(f"Label: {base_filename}")

                # 显示带有两个子图的图像
                plt.show()
            else:
                print(f"警告：图像 '{file}' 和标签 '{label_filename}' 尺寸不匹配！")
        else:
            print(f"警告：找不到标签文件 '{label_filename}' 对应于图像 '{file}'！")
            
'''
# 示例：调用函数并传入图像和标签的路径
image_folder = 'processing/positive/images/'  # 替换为实际的图像文件夹路径
label_folder = 'processing/positive/labels/'  # 替换为实际的标签文件夹路径
display_images_and_labels(image_folder, label_folder)
'''


import os

def synchronize_folders(images_folder, labels_folder):
    """
    同步两个文件夹，确保每个图像文件夹中的文件都有对应的标签文件。
    
    参数:
    - images_folder: 存放图像的文件夹路径
    - labels_folder: 存放标签的文件夹路径
    """
    # 获取所有图像文件名（不包括扩展名）
    image_names = set([os.path.splitext(f)[0] for f in os.listdir(images_folder) if f.endswith('.jpg')])
    label_names = set([os.path.splitext(f)[0] for f in os.listdir(labels_folder) if f.endswith('.png')])

    # 找出在images_folder中存在，而在labels_folder中不存在的文件，并删除这些文件
    for name in image_names.difference(label_names):
        image_path = os.path.join(images_folder, name + '.jpg')
        if os.path.exists(image_path):
            os.remove(image_path)
            print(f"删除图像文件: {image_path}")

    # 找出在labels_folder中存在，而在images_folder中不存在的文件，并删除这些文件
    for name in label_names.difference(image_names):
        label_path = os.path.join(labels_folder, name + '.png')
        if os.path.exists(label_path):
            os.remove(label_path)
            print(f"删除标签文件: {label_path}")

    # 确保images_folder和labels_folder中的文件数量相同
    if len(os.listdir(images_folder)) != len(os.listdir(labels_folder)):
        print("警告：文件夹中的文件数量不匹配！")
    else:
        print("文件夹中的文件数量匹配。")

    # 确保images_folder和labels_folder中的每个文件名相同（不包括扩展名）
    for image_file, label_file in zip(os.listdir(images_folder), os.listdir(labels_folder)):
        if os.path.splitext(image_file)[0] != os.path.splitext(label_file)[0]:
            print(f"警告：文件名不匹配：{image_file} 和 {label_file}")
        else:
            print(f"文件名匹配：{image_file} 和 {label_file}")
            
'''
# 示例：调用函数并传入图像和标签文件夹路径
images_folder = 'processing/positive/images/'  # 替换为实际的图像文件夹路径
labels_folder = 'processing/positive/labels/'  # 替换为实际的标签文件夹路径
synchronize_folders(images_folder, labels_folder)
'''


import os
import random
import shutil

def split_dataset(images_path, labels_path, train_images_path, val_images_path, test_images_path, train_labels_path, val_labels_path, test_labels_path, train_ratio=0.7, val_ratio=0.15, test_ratio=0.15, seed=42):
    """
    将图像和标签数据集划分为训练集、验证集和测试集，并复制到相应的文件夹中。

    参数:
    - images_path: 原始图像文件夹路径
    - labels_path: 原始标签文件夹路径
    - train_images_path: 训练集图像文件夹路径
    - val_images_path: 验证集图像文件夹路径
    - test_images_path: 测试集图像文件夹路径
    - train_labels_path: 训练集标签文件夹路径
    - val_labels_path: 验证集标签文件夹路径
    - test_labels_path: 测试集标签文件夹路径
    - train_ratio: 训练集所占比例，默认为0.7
    - val_ratio: 验证集所占比例，默认为0.15
    - test_ratio: 测试集所占比例，默认为0.15
    - seed: 随机种子，默认为42
    """
    
    # 设置随机种子
    random.seed(seed)

    # 创建训练集、验证集和测试集的目录
    os.makedirs(train_images_path, exist_ok=True)
    os.makedirs(val_images_path, exist_ok=True)
    os.makedirs(test_images_path, exist_ok=True)
    os.makedirs(train_labels_path, exist_ok=True)
    os.makedirs(val_labels_path, exist_ok=True)
    os.makedirs(test_labels_path, exist_ok=True)

    # 获取images目录中的所有JPEG文件
    image_files = [file for file in os.listdir(images_path) if file.endswith('.jpg')]

    # 随机打乱文件列表
    random.shuffle(image_files)

    # 计算分配数量
    num_total_images = len(image_files)
    num_test_images = int(test_ratio * num_total_images)
    num_val_images = int(val_ratio * num_total_images)
    num_train_images = num_total_images - num_test_images - num_val_images

    # 分配训练集
    train_image_files = image_files[:num_train_images]
    for image_file in train_image_files:
        image_src = os.path.join(images_path, image_file)
        image_dst = os.path.join(train_images_path, image_file)
        shutil.copy(image_src, image_dst)

        label_file = image_file.replace('.jpg', '.png')
        label_src = os.path.join(labels_path, label_file)
        label_dst = os.path.join(train_labels_path, label_file)
        shutil.copy(label_src, label_dst)

    # 分配验证集
    val_image_files = image_files[num_train_images:num_train_images+num_val_images]
    for image_file in val_image_files:
        image_src = os.path.join(images_path, image_file)
        image_dst = os.path.join(val_images_path, image_file)
        shutil.copy(image_src, image_dst)

        label_file = image_file.replace('.jpg', '.png')
        label_src = os.path.join(labels_path, label_file)
        label_dst = os.path.join(val_labels_path, label_file)
        shutil.copy(label_src, label_dst)

    # 分配测试集
    test_image_files = image_files[num_train_images+num_val_images:]
    for image_file in test_image_files:
        image_src = os.path.join(images_path, image_file)
        image_dst = os.path.join(test_images_path, image_file)
        shutil.copy(image_src, image_dst)

        label_file = image_file.replace('.jpg', '.png')
        label_src = os.path.join(labels_path, label_file)
        label_dst = os.path.join(test_labels_path, label_file)
        shutil.copy(label_src, label_dst)

    print("数据集划分完成！")

'''
# 示例：调用函数
images_path = 'output/images/'
labels_path = 'output/labels/'
train_images_path = 'train/images/'
val_images_path = 'val/images/'
test_images_path = 'test/images/'
train_labels_path = 'train/labels/'
val_labels_path = 'val/labels/'
test_labels_path = 'test/labels/'

split_dataset(images_path, labels_path, train_images_path, val_images_path, test_images_path, train_labels_path, val_labels_path, test_labels_path)
'''


import os
import cv2
import numpy as np
import matplotlib.pyplot as plt
from scipy.ndimage import gaussian_filter1d  # 导入高斯平滑函数

# 定义函数加载图像
def load_images_from_folder(folder):
    """
    从文件夹加载所有图像，并返回图像列表。
    
    参数:
    folder (str): 图像所在的文件夹路径
    
    返回:
    list: 图像列表
    """
    images = []
    for root, dirs, files in os.walk(folder):
        for filename in files:
            img = cv2.imread(os.path.join(root, filename), cv2.IMREAD_UNCHANGED)  # 加载图像
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            if img is not None:
                images.append(img)
    return images

# 定义函数计算并平滑直方图，并可视化结果
def plot_histograms(train_folder, val_folder, test_folder, sigma=2, save_path='histogram_curve.svg'):
    """
    加载训练集、验证集和测试集图像，计算它们的像素值分布，进行高斯平滑并可视化结果。
    
    参数:
    train_folder (str): 训练集图像文件夹路径
    val_folder (str): 验证集图像文件夹路径
    test_folder (str): 测试集图像文件夹路径
    sigma (int): 高斯平滑的标准差
    save_path (str): 保存可视化结果的路径
    
    返回:
    None
    """
    # 加载图像
    train_images = load_images_from_folder(train_folder)
    val_images = load_images_from_folder(val_folder)
    test_images = load_images_from_folder(test_folder)
    
    # 计算图像像素值的频率分布
    train_hist = np.concatenate(train_images).ravel()
    val_hist = np.concatenate(val_images).ravel()
    test_hist = np.concatenate(test_images).ravel()
    
    # 计算每个像素值的频率
    train_hist_freq, train_bins = np.histogram(train_hist, bins=256, range=(0, 255), density=True)
    val_hist_freq, val_bins = np.histogram(val_hist, bins=256, range=(0, 255), density=True)
    test_hist_freq, test_bins = np.histogram(test_hist, bins=256, range=(0, 255), density=True)
    
    # 获取柱的中点
    train_bin_centers = (train_bins[:-1] + train_bins[1:]) / 2
    val_bin_centers = (val_bins[:-1] + val_bins[1:]) / 2
    test_bin_centers = (test_bins[:-1] + test_bins[1:]) / 2
    
    # 使用高斯平滑来平滑频率分布
    train_hist_smooth = gaussian_filter1d(train_hist_freq, sigma=sigma)  # 使用高斯平滑
    val_hist_smooth = gaussian_filter1d(val_hist_freq, sigma=sigma)
    test_hist_smooth = gaussian_filter1d(test_hist_freq, sigma=sigma)
    
    # 可视化图像分布情况
    plt.plot(train_bin_centers, train_hist_smooth, color='blue', label='Train', linewidth=2)
    plt.plot(val_bin_centers, val_hist_smooth, color='green', label='Validation', linewidth=2)
    plt.plot(test_bin_centers, test_hist_smooth, color='red', label='Test', linewidth=2)
    
    plt.xlabel('Pixel Value')  # x 轴标签
    plt.ylabel('Frequency (Normalized)')  # y 轴标签
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    # 保存并显示图像
    plt.savefig(save_path)
    plt.show()
    
'''
# 调用函数进行图像直方图的计算和可视化
plot_histograms('crack2181/train/images', 'crack2181/val/images', 'crack2181/test/images')
'''