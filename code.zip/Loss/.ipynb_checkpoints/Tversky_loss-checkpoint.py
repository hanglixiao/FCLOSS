import torch
import torch.nn as nn
import torch.nn.functional as F

class Tversky_loss(nn.Module):
    def __init__(self, alpha=0.3, beta=0.7):
        """
        Tversky Loss 实现
        :param alpha: 假阳性惩罚系数
        :param beta: 假阴性惩罚系数
        """
        super(Tversky_loss, self).__init__()
        self.alpha = alpha
        self.beta = beta

    def forward(self, predicted, target):
        """
        :param predicted: 模型预测值，范围为 [0, 1]，形状为 (N, 1, H, W)
        :param target: 真实标签，值为 0 或 1，形状与 predicted 相同
        """
        tp = torch.sum(predicted * target)  # 真正例
        fp = torch.sum(predicted * (1 - target))  # 假正例
        fn = torch.sum((1 - predicted) * target)  # 假负例
        tversky_index = (tp + 1e-5) / (tp + self.alpha * fp + self.beta * fn + 1e-5)  # 计算 Tversky 指数
        return 1 - tversky_index  # 损失为 1 - Tversky 指数

'''
# 示例使用
y_true = torch.randint(0, 2, (1, 1, 256, 256)).float()  # 生成一个示例真实标签
y_pred = torch.randn(1, 1, 256, 256).sigmoid()  # 生成一个示例模型预测输出，已经在 [0, 1] 之间
loss = tversky_loss(y_true, y_pred)
print("Tversky Loss:", loss.item())
'''