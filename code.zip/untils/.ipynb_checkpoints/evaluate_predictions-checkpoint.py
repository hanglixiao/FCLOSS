#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import os
import cv2
import numpy as np

def evaluate_predictions(prediction_dir, true_dir):
    # 创建存储评估结果的列表
    precision_list = []
    iou_list = []
    recall_list = []
    f1_list = []

    # 获取预测结果和真实标注文件列表并排序
    prediction_files = sorted(os.listdir(prediction_dir))
    true_files = sorted(os.listdir(true_dir))

    # 遍历每个预测结果文件
    for pred_file, true_file in zip(prediction_files, true_files):
        # 加载预测结果和真实标注图像
        prediction = cv2.imread(os.path.join(prediction_dir, pred_file), cv2.IMREAD_GRAYSCALE)
        true = cv2.imread(os.path.join(true_dir, true_file), cv2.IMREAD_GRAYSCALE)  
        true[true <= 128] = 0  # 对标签数据进行阈值处理，小于等于 128 的像素值设置为 0
        true[true > 128] = 1  # 大于 128 的像素值设置为 1
        
        prediction[prediction <= 128] = 0  # 对标签数据进行阈值处理，小于等于 128 的像素值设置为 0
        prediction[prediction > 128] = 1  # 大于 128 的像素值设置为 1
        
        true_positive = np.sum(prediction & true)
        true_negative = np.sum((~prediction) & (~true))
        false_positive = np.sum(prediction & (~true))
        false_negative = np.sum((~prediction) & true)

        epsilon = 1e-7
        precision = (true_positive + epsilon) / (true_positive + false_positive + epsilon)
        recall = (true_positive + epsilon) / (true_positive + false_negative + epsilon)
        f1 = 2 * (precision * recall) / (precision + recall + epsilon)
        iou = (true_positive + epsilon) / (true_positive + false_positive + false_negative + epsilon)

        # 将评估结果添加到列表中
        precision_list.append(precision)
        iou_list.append(iou)
        recall_list.append(recall)
        f1_list.append(f1)
        #print(f"{pred_file},{precision:.4f},{recall:.4f},{f1:.4f},{iou:.4f}")
        # 打印评估结果
        #print(f"images: {pred_file}", f"precision: {precision:.4f}", f"Recall: {recall:.4f}", f"F1 Score: {f1:.4f}", f"IOU: {iou:.4f}")
        
    # 计算平均评估指标
    avg_precision = np.mean(precision_list)
    avg_iou = np.mean(iou_list)
    avg_recall = np.mean(recall_list)
    avg_f1 = np.mean(f1_list)

    # 打印平均评估结果
    print("平均值")
    print(f"   precision: {avg_precision:.4f}",f"   Recall: {avg_recall:.4f}", f"   F1 Score: {avg_f1:.4f}", f"   IOU: {avg_iou:.4f}")

#evaluate_predictions(prediction_dir, true_dir)

