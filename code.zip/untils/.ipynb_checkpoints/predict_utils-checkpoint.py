import os
import cv2
import numpy as np
import torch
import matplotlib.pyplot as plt
import time

def predict(model, input_dir, output_dir):
    # 创建输出结果目录
    os.makedirs(output_dir, exist_ok=True)
    # 初始化变量以记录总推理时间和图像数量
    total_inference_time = 0
    num_images = 0

    # 遍历每张输入图片
    for f in os.listdir(input_dir):  
        # 读取图像
        image = cv2.imread(os.path.join(input_dir, f), cv2.IMREAD_COLOR)

        # 将图像归一化并增加一个维度作为批处理
        img = np.float32(image) / 255.0  
        img = np.transpose(img, (2, 0, 1))
        img = np.expand_dims(img, 0)

        # 将图像传递给模型进行预测
        x_input = torch.from_numpy(img).cuda()
        start_time = time.time()  # 记录开始时间
        probs = model(x_input, inference=True)

        # 记录结束时间
        end_time = time.time()

        # 计算推理时间
        inference_time = end_time - start_time

        # 累积总推理时间和图像数量
        total_inference_time += inference_time
        num_images += 1

        # 对输出结果进行处理，将概率值大于0.5的像素点设为255，其余为0
        mask = (probs > 0.5).float()
        prediction = (mask * 255).cpu().numpy().astype(np.uint8)

        # 保存结果图像为PNG格式
        result_image_path = os.path.join(output_dir, os.path.splitext(f)[0] + ".png")
        cv2.imwrite(result_image_path, prediction[0][0])
        '''  
        # 显示输入图像和预测结果
        plt.figure()
        plt.subplot(121)
        plt.imshow(image, cmap='gray')
        plt.title('Image: {}'.format(os.path.splitext(f)[0]))
        plt.subplot(122)
        plt.imshow(prediction[0][0], cmap='gray')  
        plt.title('Prediction: {}'.format(os.path.splitext(f)[0]))
        plt.show()
        '''
    # 计算平均推理时间和FPS
    if num_images > 0:
        average_inference_time = total_inference_time / num_images
        average_fps = num_images / total_inference_time
        print(f"Average inference time: {average_inference_time} seconds")
        print(f"Average FPS: {average_fps} frames per second")
    else:
        print("No images processed yet, please check your input directory.")