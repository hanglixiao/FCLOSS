import torch
import torch.nn as nn
import torch.nn.functional as F

class FocalLoss(nn.Module):
    def __init__(self, alpha=0.25, gamma=2.0):
        """
        Focal Loss 实现
        :param alpha: 平衡参数，用于减少正负样本不平衡的影响
        :param gamma: 焦点参数，用于关注难分类样本
        """
        super(FocalLoss, self).__init__()
        self.alpha = alpha
        self.gamma = gamma

    def forward(self, predicted, target):
        """
        :param predicted: 模型预测值，范围为 [0, 1]，形状为 (N, 1, H, W)
        :param target: 真实标签，值为 0 或 1，形状与 predicted 相同
        """
        bce_loss = F.binary_cross_entropy(predicted, target, reduction='none')  # 逐像素计算交叉熵
        pt = torch.exp(-bce_loss)  # pt 表示预测的置信度
        focal_loss = self.alpha * (1 - pt) ** self.gamma * bce_loss  # 应用 Focal Loss 的公式
        return focal_loss.mean()  # 返回平均损失

