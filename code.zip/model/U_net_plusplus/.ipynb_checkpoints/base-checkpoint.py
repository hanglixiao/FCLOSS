#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import torch
import torch.nn as nn
import torch.nn.functional as F
import itertools

class Correlation(torch.nn.Module):
    def __init__(self):
        super(Correlation, self).__init__()

    def forward(self, x):
        # 获取张量的维度
        N, C, H, W = x.size()

        x_reshaped = x.view(N, C, -1)  # 形状: (N, C, H*W)
        x_mean = x_reshaped.mean(dim=2, keepdim=True)  # 平均值 (N, C, 1)
        x_centered = x_reshaped - x_mean  # 中心化 (N, C, H*W)
        x_norm = torch.norm(x_centered, dim=2, keepdim=True)  # 归一化因子 (N, C, 1)
        x_normalized = x_centered / (x_norm + 1e-8)  # 归一化 (N, C, H*W)

        # 计算皮尔逊相关系数
        correlation_matrix = torch.bmm(x_normalized, x_normalized.transpose(1, 2))  # (N, C, C)

        # 对角线上的值即为每个通道与自身的相关系数，将其置为0
        for i in range(C):
            correlation_matrix[:, i, i] = 0

        # 取绝对值并计算总和，然后除以通道数的组合数以得到平均值
        absolute_correlation = torch.abs(correlation_matrix)
        total_correlation = absolute_correlation.sum()
        num_combinations = len(list(itertools.combinations(range(C), 2)))  # 通道数的组合数
        average_correlation = total_correlation / num_combinations / 2 / N

        return average_correlation

class UNetBlock(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(UNetBlock, self).__init__()
        self.block = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1, stride=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(),
            nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1, stride=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU()
        )
    
    def forward(self, x):
        return self.block(x)

class Model(nn.Module):
    def __init__(self, in_features, out_features, init_features):
        super(Model, self).__init__()
        features = init_features
        
        self.encode_layer_1_32 = UNetBlock(in_features, features)
        self.encode_layer_32_64= UNetBlock(features, features * 2)
        self.encode_layer_64_128 = UNetBlock(features * 2, features * 4)
        self.encode_layer_128_256 = UNetBlock(features * 4, features * 8)
        self.encode_layer_256_512 = UNetBlock(features * 8, features * 16)
        
        self.pool = nn.MaxPool2d(kernel_size=2, stride=2)
        
        self.upconv_512_256 = nn.ConvTranspose2d(features * 16, features * 8, kernel_size=2, stride=2)
        self.upconv_256_128 = nn.ConvTranspose2d(features * 8, features * 4, kernel_size=2, stride=2)
        self.upconv_128_64 = nn.ConvTranspose2d(features * 4, features * 2, kernel_size=2, stride=2)
        self.upconv_64_32 = nn.ConvTranspose2d(features * 2, features, kernel_size=2, stride=2)
        
        self.decode_layer_512_256 = UNetBlock(features * 16, features * 8)
        
        self.decode_layer_256_128 = UNetBlock(features * 8, features * 4)
        self.decode_layer_384_128 = UNetBlock(features * 12, features * 4)
        
        self.decode_layer_128_64 = UNetBlock(features * 4, features * 2)
        self.decode_layer_192_64 = UNetBlock(features * 6, features * 2)
        self.decode_layer_256_64 = UNetBlock(features * 8, features * 2)
        
        self.decode_layer_64_32 = UNetBlock(features * 2, features)
        self.decode_layer_96_32 = UNetBlock(features * 3, features)
        self.decode_layer_128_32 = UNetBlock(features * 4, features)
        self.decode_layer_160_32 = UNetBlock(features * 5, features)
        
        self.out_layer = nn.Sequential(
            nn.Conv2d(features * 4, out_features, kernel_size=1, padding=0, stride=1),
            nn.Sigmoid()
        )
        
        self.correlation_module = Correlation()
        
    def forward(self, x, inference=False):
        
        x0_0 = self.encode_layer_1_32(x)
        x1_0 = self.encode_layer_32_64(self.pool(x0_0))
        x2_0 = self.encode_layer_64_128(self.pool(x1_0))
        x3_0 = self.encode_layer_128_256(self.pool(x2_0))
        x4_0 = self.encode_layer_256_512(self.pool(x3_0))
        
        x3_1 = self.upconv_512_256(x4_0)
        x3_1 = torch.cat((x3_0, x3_1), dim=1)
        x3_1 = self.decode_layer_512_256(x3_1)
        
        x2_1 = self.upconv_256_128(x3_0)
        x2_1 = torch.cat((x2_0, x2_1), dim=1)
        x2_1 = self.decode_layer_256_128(x2_1)
        
        x2_2 = self.upconv_256_128(x3_1)
        x2_2 = torch.cat((x2_0, x2_1, x2_2), dim=1)
        x2_2 = self.decode_layer_384_128(x2_2)
        
        x1_1 = self.upconv_128_64(x2_0)
        x1_1 = torch.cat((x1_0, x1_1), dim=1)
        x1_1 = self.decode_layer_128_64(x1_1)
        
        x1_2 = self.upconv_128_64(x2_1)
        x1_2 = torch.cat((x1_0, x1_1, x1_2), dim=1)
        x1_2 = self.decode_layer_192_64(x1_2)
        
        x1_3 = self.upconv_128_64(x2_2)
        x1_3 = torch.cat((x1_0, x1_1, x1_2, x1_3), dim=1)
        x1_3 = self.decode_layer_256_64(x1_3)
        
        x0_1 = self.upconv_64_32 (x1_0)
        x0_1 = torch.cat((x0_0, x0_1), dim=1)
        x0_1 = self.decode_layer_64_32(x0_1)
        
        x0_2 = self.upconv_64_32(x1_1)
        x0_2 = torch.cat((x0_0, x0_1, x0_2), dim=1)
        x0_2 = self.decode_layer_96_32(x0_2)
        
        x0_3 = self.upconv_64_32(x1_2)
        x0_3 = torch.cat((x0_0, x0_1, x0_2, x0_3), dim=1)
        x0_3 = self.decode_layer_128_32(x0_3)
        
        x0_4 = self.upconv_64_32(x1_3)
        x0_4 = torch.cat((x0_0, x0_1, x0_2, x0_3, x0_4), dim=1)
        x0_4 = self.decode_layer_160_32(x0_4)
        
        out = torch.cat((x0_1, x0_2, x0_3, x0_4), dim=1)
        out = self.out_layer(out)
        
        if not inference:  # 如果非推理模式，执行以下计算
            cor1 = self.correlation_module(x0_0)
            cor2 = self.correlation_module(x1_0)
            cor3 = self.correlation_module(x2_0)
            cor4 = self.correlation_module(x3_0)
            cor5 = self.correlation_module(x4_0)
            
            return out, cor1, cor2, cor3, cor4, cor5 # 在非推理模式返回相应计算结果

        return out  # 在推理模式下，只返回 out
