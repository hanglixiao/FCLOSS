import torch
import torch.nn as nn
import torch.nn.functional as F
import itertools

class Correlation(torch.nn.Module):
    def __init__(self):
        super(Correlation, self).__init__()

    def forward(self, x):
        # 获取张量的维度
        N, C, H, W = x.size()

        x_reshaped = x.view(N, C, -1)  # 形状: (N, C, H*W)
        x_mean = x_reshaped.mean(dim=2, keepdim=True)  # 平均值 (N, C, 1)
        x_centered = x_reshaped - x_mean  # 中心化 (N, C, H*W)
        x_norm = torch.norm(x_centered, dim=2, keepdim=True)  # 归一化因子 (N, C, 1)
        x_normalized = x_centered / (x_norm + 1e-8)  # 归一化 (N, C, H*W)

        # 计算皮尔逊相关系数
        correlation_matrix = torch.bmm(x_normalized, x_normalized.transpose(1, 2))  # (N, C, C)

        # 对角线上的值即为每个通道与自身的相关系数，将其置为0
        for i in range(C):
            correlation_matrix[:, i, i] = 0

        # 取绝对值并计算总和，然后除以通道数的组合数以得到平均值
        absolute_correlation = torch.abs(correlation_matrix)
        total_correlation = absolute_correlation.sum()
        num_combinations = len(list(itertools.combinations(range(C), 2)))  # 通道数的组合数
        average_correlation = total_correlation / num_combinations / 2 / N

        return average_correlation

# 定义基本的残差块
class BasicBlock(nn.Module):
    expansion = 1

    def __init__(self, in_planes, planes, stride=1):
        super(BasicBlock, self).__init__()
        self.conv1 = nn.Conv2d(in_planes, planes, kernel_size=3, stride=stride, padding=1)
        self.bn1 = nn.BatchNorm2d(planes)
        self.conv2 = nn.Conv2d(planes, planes, kernel_size=3, stride=1, padding=1)
        self.bn2 = nn.BatchNorm2d(planes)

        self.shortcut = nn.Sequential()
        if stride != 1 or in_planes != self.expansion*planes:
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_planes, self.expansion*planes, kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm2d(self.expansion*planes)
            )

    def forward(self, x):
        out = F.relu(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        out += self.shortcut(x)
        out = F.relu(out)
        return out
    
class UNetBlock(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(UNetBlock, self).__init__()
        self.block = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1, stride=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(),
            nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1, stride=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU()
        )
    
    def forward(self, x):
        return self.block(x)
    
# 定义ResNet主体结构
class UNetModel(nn.Module):
    def __init__(self, in_features, out_features, init_features):
        super(UNetModel, self).__init__()
        features = init_features
        self.conv1 = nn.Conv2d(3, features, kernel_size=7, stride=2, padding=3, bias=False)
        self.bn1 = nn.BatchNorm2d(features)
        self.pool = nn.MaxPool2d(kernel_size=2, stride=2)

        # 编码器部分
        self.layer1 = nn.Sequential(
            BasicBlock(in_planes=features, planes=features, stride=1),
            BasicBlock(in_planes=features, planes=features, stride=1)
        )
        self.layer2 = nn.Sequential(
            BasicBlock(in_planes=features, planes=features, stride=1),
            BasicBlock(in_planes=features, planes=features * 2, stride=2)
        )
        self.layer3 = nn.Sequential(
            BasicBlock(in_planes=features * 2, planes=features * 2, stride=1),
            BasicBlock(in_planes=features * 2, planes=features * 2, stride=1)
        )
        self.layer4 = nn.Sequential(
            BasicBlock(in_planes=features * 2, planes=features * 2, stride=1),
            BasicBlock(in_planes=features * 2, planes=features * 4, stride=2)
        )
        self.layer5 = nn.Sequential(
            BasicBlock(in_planes=features * 4, planes=features * 4, stride=1),
            BasicBlock(in_planes=features * 4, planes=features * 4, stride=1)
        )
        self.layer6 = nn.Sequential(
            BasicBlock(in_planes=features * 4, planes=features * 4, stride=1),
            BasicBlock(in_planes=features * 4, planes=features * 4, stride=1)
        )
        self.layer7 = nn.Sequential(
            BasicBlock(in_planes=features * 4, planes=features * 4, stride=1),
            BasicBlock(in_planes=features * 4, planes=features * 8, stride=2)
        )
        self.layer8 = nn.Sequential(
            BasicBlock(in_planes=features * 8, planes=features * 8, stride=1),
            BasicBlock(in_planes=features * 8, planes=features * 8, stride=1)
        )
        
        # 解码器部分
        self.deconv1 = nn.ConvTranspose2d(features * 8, features * 4, kernel_size=2, stride=2)
        self.dec1 = UNetBlock(features * 8, features * 4)
        self.deconv2 = nn.ConvTranspose2d(features * 4, features * 2, kernel_size=2, stride=2)
        self.dec2 = UNetBlock(features * 4, features * 2)
        self.deconv3 = nn.ConvTranspose2d(features * 2, features, kernel_size=2, stride=2)
        self.dec3 = UNetBlock(features * 2, features)
        self.deconv4 = nn.ConvTranspose2d(features, features, kernel_size=2, stride=2)
        self.dec4 = UNetBlock(features * 2, features)
        self.deconv5 = nn.ConvTranspose2d(features, features, kernel_size=2, stride=2)
        self.dec5 = UNetBlock(features, features)
        
        self.out_layer = nn.Sequential(
            nn.Conv2d(features, out_features, kernel_size=1, padding=0, stride=1),
            nn.Sigmoid()
        )
        self.correlation_module = Correlation()
        
    def forward(self, x, inference=False):
        # 编码器部分
        x = F.relu(self.bn1(self.conv1(x)))#128
        enc0 = self.pool(x)#64
        enc1 = self.layer1(enc0)
        enc2 = self.layer2(enc1)#32
        enc3 = self.layer3(enc2)
        enc4 = self.layer4(enc3)#16
        enc5 = self.layer5(enc4)
        enc6 = self.layer6(enc5)
        enc7 = self.layer7(enc6)#8
        enc8 = self.layer8(enc7)
        
        # 解码器部分
        dec1 = self.deconv1(enc8)#16
        dec1 = torch.cat((enc6, dec1), dim=1)
        dec1 = self.dec1(dec1)
        dec2 = self.deconv2(dec1)#32
        dec2 = torch.cat((enc3, dec2), dim=1)
        dec2 = self.dec2(dec2)
        dec3 = self.deconv3(dec2)#64
        dec3 = torch.cat((enc1, dec3), dim=1)
        dec3 = self.dec3(dec3)
        dec4 = self.deconv4(dec3)#128
        dec4 = torch.cat((x, dec4), dim=1)
        dec4 = self.dec4(dec4)
        dec5 = self.deconv5(dec4)#256
        dec5 = self.dec5(dec5)
        out = self.out_layer(dec5)
        
        if not inference:  # 如果非推理模式，执行以下计算
            cor1 = self.correlation_module(enc0)
            cor2 = self.correlation_module(enc1)
            cor3 = self.correlation_module(enc2)
            cor4 = self.correlation_module(enc3)
            cor5 = self.correlation_module(enc4)
            
            return out, cor1, cor2, cor3, cor4, cor5 # 在非推理模式返回相应计算结果

        return out  # 在推理模式下，只返回 out