import torch
import torch.nn as nn
import torch.nn.functional as F
import itertools

class Similarity(nn.Module):
    def __init__(self):
        super(Similarity, self).__init__()

    def forward(self, x):
        # 获取输入张量的形状
        N, C, H, W = x.shape

        # 将输入张量从四维变为三维
        x = x.view(N, C, H * W)

        # 计算余弦相似度
        # 首先对x进行L2归一化
        x_normalized = F.normalize(x, dim=2, p=2)
        
        # 使用批量矩阵乘法计算相似度
        similarities = torch.bmm(x_normalized, x_normalized.transpose(1, 2))
        similarities = (similarities+1)/2

        # 排除对角线上的相似度，因为它们表示了通道自身的相似度
        mask = torch.eye(C).to(x.device)
        similarities = similarities * (1 - mask)

        # 计算每对通道之间的平均相似度
        total_similarity = similarities.sum()
        num_combinations = len(list(itertools.combinations(range(C), 2)))
        avg_similarity = total_similarity / num_combinations / 2 / N

        return avg_similarity

class StandardBlock(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(StandardBlock, self).__init__()
        self.block = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1, stride=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(),
            nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1, stride=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(),
        )
    
    def forward(self, x):
        return self.block(x)

class UNetModel(nn.Module):
    def __init__(self, in_features, out_features, init_features): 
        super(UNetModel, self).__init__()
        features = init_features

        self.encode_layer1 = StandardBlock(in_features, features)  
        self.encode_layer2 = StandardBlock(features, features * 2)
        self.encode_layer3 = StandardBlock(features * 2, features * 4)
        self.encode_layer4 = StandardBlock(features * 4, features * 8)
        self.encode_decode_layer = StandardBlock(features * 8, features * 16)

        self.pool = nn.MaxPool2d(kernel_size=2, stride=2)

        self.upconv4 = nn.ConvTranspose2d(features * 16, features * 8, kernel_size=2, stride=2)
        self.upconv3 = nn.ConvTranspose2d(features * 8, features * 4, kernel_size=2, stride=2)
        self.upconv2 = nn.ConvTranspose2d(features * 4, features * 2, kernel_size=2, stride=2)
        self.upconv1 = nn.ConvTranspose2d(features * 2, features, kernel_size=2, stride=2)

        self.decode_layer4 = StandardBlock(features * 16, features * 8)
        self.decode_layer3 = StandardBlock(features * 8, features * 4)
        self.decode_layer2 = StandardBlock(features * 4, features * 2)
        self.decode_layer1 = StandardBlock(features * 2, features)

        self.out_layer = nn.Sequential(
            nn.Conv2d(features, out_features, kernel_size=1, padding=0, stride=1),
            nn.Sigmoid()
        )

        self.correlation_module = Similarity()

    def forward(self, x, inference=False):
        enc1 = self.encode_layer1(x)
        output1 = self.pool(enc1)

        enc2 = self.encode_layer2(output1)
        output2 = self.pool(enc2)

        enc3 = self.encode_layer3(output2)
        output3 = self.pool(enc3)

        enc4 = self.encode_layer4(output3)
        output4 = self.pool(enc4)

        bottleneck = self.encode_decode_layer(output4)

        dec4 = self.upconv4(bottleneck)
        dec4 = torch.cat((dec4, enc4), dim=1)
        dec4 = self.decode_layer4(dec4)

        dec3 = self.upconv3(dec4)
        dec3 = torch.cat((dec3, enc3), dim=1)
        dec3 = self.decode_layer3(dec3)

        dec2 = self.upconv2(dec3)
        dec2 = torch.cat((dec2, enc2), dim=1)
        dec2 = self.decode_layer2(dec2)

        dec1 = self.upconv1(dec2)
        dec1 = torch.cat((dec1, enc1), dim=1)
        dec1 = self.decode_layer1(dec1)

        out = self.out_layer(dec1)
        
        if not inference:  # 如果非推理模式，执行以下计算
            cor1 = self.correlation_module(output1)
            cor2 = self.correlation_module(output2)
            cor3 = self.correlation_module(output3)
            cor4 = self.correlation_module(output4)
            cor5 = self.correlation_module(bottleneck)
            
            return out, cor1, cor2, cor3, cor4, cor5 # 在非推理模式返回相应计算结果

        return out  # 在推理模式下，只返回 out