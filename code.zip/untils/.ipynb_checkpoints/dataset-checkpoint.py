#!/usr/bin/env python
# coding: utf-8

import os
import numpy as np
import cv2
import torch

class SegmentationDataset(object):
    def __init__(self, root_dir):
        self.images = []  # 存储图像文件路径
        self.labels = []  # 存储标签文件路径
        images_dir = os.path.join(root_dir, 'images')
        labels_dir = os.path.join(root_dir, 'labels')
        files = os.listdir(images_dir)
        lfiles = os.listdir(labels_dir)

        # 对文件名进行排序
        files.sort()
        lfiles.sort()

        for i in range(len(files)):
            img_file = os.path.join(images_dir, files[i])
            label_file = os.path.join(labels_dir, lfiles[i])
            self.images.append(img_file)
            self.labels.append(label_file)

    def __len__(self):
        return len(self.images)

    def __getitem__(self, idx):
        if torch.is_tensor(idx):
            idx = idx.tolist()
        image_path = self.images[idx]
        label_path = self.labels[idx]
        
        img = cv2.imread(image_path, cv2.IMREAD_COLOR)  # 以RGB图像读取图像数据[256, 256, 3]
        label = cv2.imread(label_path, cv2.IMREAD_GRAYSCALE)  # 以灰度图像读取标签数据[256, 256]
        
        img = np.float32(img) / 255.0  # 归一化图像数据，将像素值缩放到 0~1 范围[256, 256, 3]/255
        img = np.transpose(img, (2, 0, 1))#交换维度[3, 256, 256]
        
        label[label <= 128] = 0  # 对标签数据进行阈值处理，小于等于 128 的像素值设置为 0
        label[label > 128] = 1  # 大于 128 的像素值设置为 1
        label = np.expand_dims(label, 0)  # 在通道维度上扩展数组[1, 256, 256]
        
        sample = {'image': torch.from_numpy(img), 'label': torch.from_numpy(label)}  # 将图像和标签数据打包为字典
        return sample