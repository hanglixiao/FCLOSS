#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import torch
import numpy as np
from tqdm import tqdm
import matplotlib.pyplot as plt
import time


def train_and_validate(model, train_loader, val_loader, optimizer, loss_fn, num_epochs, patience, train_on_gpu=False):
    train_losses = []
    val_losses = []
    ious = []
    recalls = []
    f1_scores = []
    precisions = []
    train_cor1_values = []
    train_cor2_values = []
    train_cor3_values = []
    train_cor4_values = []
    train_cor5_values = []
    
    best_iou = 0.0
    best_epoch = 0
    best_model_state = None
    
    start_time = time.time()  # 记录开始时间
    
    for epoch in range(num_epochs):
        # 训练阶段
        model.train()
        train_loss = 0.0
        train_cor1_value = 0.0
        train_cor2_value = 0.0
        train_cor3_value = 0.0
        train_cor4_value = 0.0
        train_cor5_value = 0.0

        with tqdm(total=len(train_loader), desc=f"Epoch [{epoch + 1}/{num_epochs}]") as pbar:
            for i_batch, sample_batched in enumerate(train_loader):
                images_batch, target_labels = sample_batched['image'], sample_batched['label']

                if train_on_gpu:
                    images_batch, target_labels = images_batch.cuda(), target_labels.cuda()

                optimizer.zero_grad()
                output_tuple = model(images_batch)
                m_label_out_ = output_tuple[0]  # 获取语义分割结果
                cor1, cor2, cor3, cor4, cor5 = output_tuple[1:]
                loss = loss_fn(m_label_out_, target_labels.float())
                loss.backward()
                optimizer.step()

                train_loss += loss.item()
                train_cor1_value += cor1.item()
                train_cor2_value += cor2.item()
                train_cor3_value += cor3.item()
                train_cor4_value += cor4.item()
                train_cor5_value += cor5.item()

                pbar.update(1)
                pbar.set_postfix({"Train Loss": f"{train_loss / (i_batch + 1):.4f}",
                                  "Cor1": f"{train_cor1_value / (i_batch + 1):.4f}",
                                  "Cor2": f"{train_cor2_value / (i_batch + 1):.4f}",
                                  "Cor3": f"{train_cor3_value / (i_batch + 1):.4f}",
                                  "Cor4": f"{train_cor4_value / (i_batch + 1):.4f}",
                                  "Cor5": f"{train_cor5_value / (i_batch + 1):.4f}"})

        train_loss /= len(train_loader)
        train_cor1_value /= len(train_loader)
        train_cor2_value /= len(train_loader)
        train_cor3_value /= len(train_loader)
        train_cor4_value /= len(train_loader)
        train_cor5_value /= len(train_loader)

        train_losses.append(train_loss)
        train_cor1_values.append(train_cor1_value)
        train_cor2_values.append(train_cor2_value)
        train_cor3_values.append(train_cor3_value)
        train_cor4_values.append(train_cor4_value)
        train_cor5_values.append(train_cor5_value)

        # 验证阶段
        model.eval()
        val_loss = 0.0
        val_precision = 0.0
        val_recall = 0.0
        val_f1 = 0.0
        val_iou = 0.0

        with tqdm(total=len(val_loader), desc=f"Epoch [{epoch + 1}/{num_epochs}]", dynamic_ncols=True) as pbar:
            for i_batch, sample_batched in enumerate(val_loader):
                images_batch, target_labels = sample_batched['image'], sample_batched['label']

                if train_on_gpu:
                    images_batch, target_labels = images_batch.cuda(), target_labels.cuda()

                m_label_out_ = model(images_batch, inference=True)
                loss = loss_fn(m_label_out_, target_labels.float())

                val_loss += loss.item()

                true = target_labels.cpu().numpy()
                prediction = (m_label_out_.detach().cpu().numpy() > 0.5).astype(int)

                true_positive = np.sum(prediction & true)
                true_negative = np.sum((~prediction) & (~true))
                false_positive = np.sum(prediction & (~true))
                false_negative = np.sum((~prediction) & true)

                epsilon = 1e-7
                precision = (true_positive + epsilon) / (true_positive + false_positive + epsilon)
                recall = (true_positive + epsilon) / (true_positive + false_negative + epsilon)
                f1 = 2 * (precision * recall) / (precision + recall + epsilon)
                iou = (true_positive + epsilon) / (true_positive + false_positive + false_negative + epsilon)

                val_precision += precision
                val_recall += recall
                val_f1 += f1
                val_iou += iou

                pbar.update(1)
                pbar.set_postfix({"Val Loss": f"{val_loss / (i_batch + 1):.4f}",
                                  "Precision": f"{val_precision / (i_batch + 1):.4f}",
                                  "Recall": f"{val_recall / (i_batch + 1):.4f}",
                                  "F1 Score": f"{val_f1 / (i_batch + 1):.4f}",
                                  "IoU": f"{val_iou / (i_batch + 1):.4f}"})

        val_loss /= len(val_loader)
        val_precision /= len(val_loader)
        val_recall /= len(val_loader)
        val_f1 /= len(val_loader)
        val_iou /= len(val_loader)

        val_losses.append(val_loss)
        ious.append(val_iou)
        recalls.append(val_recall)
        f1_scores.append(val_f1)
        precisions.append(val_precision)

        if epoch >= num_epochs - patience:
            if val_iou > best_iou:
                best_iou = val_iou
                best_epoch = epoch + 1
                best_model_state = model.state_dict()

                torch.save(best_model_state, 'u-net.pt')
                
    end_time = time.time()  # 记录结束时间
    total_training_time = end_time - start_time  # 计算整个训练所需的时间
    
    print(f"Total training time: {total_training_time:.2f} seconds")

    print(f"Best model saved at epoch {best_epoch} with IoU {best_iou:.4f}")

    plt.figure(figsize=(10, 5))
    plt.plot(train_losses, label='Train Loss')
    plt.plot(val_losses, label='Val Loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.title('Train_Val Loss')
    plt.ylim(0, 1)
    plt.xlim(0, num_epochs-1)
    plt.legend()
    plt.grid(True)
    plt.savefig('Train_Val Loss.svg')
    plt.show()

    plt.figure(figsize=(10, 5))
    plt.plot(ious, label='IoU')
    plt.plot(recalls, label='Recall')
    plt.plot(f1_scores, label='F1 Score')
    plt.plot(precisions, label='Precision')
    plt.xlabel('Epoch')
    plt.ylabel('Metrics')
    plt.title('Validation Metrics')
    plt.ylim(0, 1)
    plt.xlim(0, num_epochs-1)
    plt.legend()
    plt.grid(True)
    plt.savefig('Validation Metrics.svg')
    plt.show()
    
        # 创建一个3x3的子图布局
    plt.figure(figsize=(12, 10))

    cor_labels = ['Cor1', 'Cor2', 'Cor3', 'Cor4', 'Cor5']

    for i in range(5):
        plt.subplot(3, 3, i + 1)
        cor_name = cor_labels[i]
        cor_data_train = [train_cor1_values, train_cor2_values, train_cor3_values, train_cor4_values, train_cor5_values][i]

        # 绘制训练集的cor值曲线
        plt.plot(cor_data_train, label=f'Train {cor_name}')

        plt.xlabel('Epoch')
        plt.ylabel('Cor')
        plt.ylim(0, 1)
        plt.xlim(0, num_epochs-1)
        plt.title(f'{cor_name}')
        plt.legend()
        plt.grid(True)

    plt.tight_layout()
    plt.savefig('Cor_test.svg')
    plt.show()

# 使用示例
# train_and_validate(model, train_loader, val_loader, optimizer, loss_fn, num_epochs, patience, train_on_gpu)

