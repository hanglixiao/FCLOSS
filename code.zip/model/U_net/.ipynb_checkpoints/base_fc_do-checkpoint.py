import torch
import torch.nn as nn
import torch.nn.functional as F
import itertools

class Correlation(torch.nn.Module):
    def __init__(self):
        super(Correlation, self).__init__()

    def forward(self, x):
        # 获取张量的维度
        N, C, H, W = x.size()

        x_reshaped = x.view(N, C, -1)  # 形状: (N, C, H*W)
        x_mean = x_reshaped.mean(dim=2, keepdim=True)  # 平均值 (N, C, 1)
        x_centered = x_reshaped - x_mean  # 中心化 (N, C, H*W)
        x_norm = torch.norm(x_centered, dim=2, keepdim=True)  # 归一化因子 (N, C, 1)
        x_normalized = x_centered / (x_norm + 1e-8)  # 归一化 (N, C, H*W)

        # 计算皮尔逊相关系数
        correlation_matrix = torch.bmm(x_normalized, x_normalized.transpose(1, 2))  # (N, C, C)

        # 对角线上的值即为每个通道与自身的相关系数，将其置为0
        for i in range(C):
            correlation_matrix[:, i, i] = 0

        # 取绝对值并计算总和，然后除以通道数的组合数以得到平均值
        absolute_correlation = torch.abs(correlation_matrix)
        total_correlation = absolute_correlation.sum()
        num_combinations = len(list(itertools.combinations(range(C), 2)))  # 通道数的组合数
        average_correlation = total_correlation / num_combinations / 2 / N

        return average_correlation

class StandardBlock(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(StandardBlock, self).__init__()
        self.block = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1, stride=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(),
            nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1, stride=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(),
        )
    def forward(self, x):
        return self.block(x)
    
class DoBlock(nn.Module):
    def __init__(self, in_channels, out_channels, dropout_rate):
        super(DoBlock, self).__init__()
        self.block = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1, stride=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(),
            nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1, stride=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(),
            nn.Dropout2d(dropout_rate)  # 在这里添加 dropout2d 层
        )
    
    def forward(self, x):
        return self.block(x)
    
class Model4(nn.Module):
    def __init__(self, in_features, out_features, init_features, factor, dropout_rate):
        super(Model4,self).__init__()
        features = init_features

        self.encode_layer1 = StandardBlock(in_features, features)  
        self.encode_layer2 = StandardBlock(features, features * 2)
        self.encode_layer3 = StandardBlock(features * 2, features * 4)
        self.encode_layer4 = StandardBlock(features * 4, features * 8)
        self.encode_decode_layer = DoBlock(features * 8, features * 16, dropout_rate)

        self.pool = nn.MaxPool2d(kernel_size=2, stride=2)

        self.upconv4 = nn.ConvTranspose2d(features * 16, features * 8, kernel_size=2, stride=2)
        self.upconv3 = nn.ConvTranspose2d(features * 8, features * 4, kernel_size=2, stride=2)
        self.upconv2 = nn.ConvTranspose2d(features * 4, features * 2, kernel_size=2, stride=2)
        self.upconv1 = nn.ConvTranspose2d(features * 2, features, kernel_size=2, stride=2)

        self.decode_layer4 = StandardBlock(features * 16, features * 8)
        self.decode_layer3 = StandardBlock(features * 8, features * 4)
        self.decode_layer2 = StandardBlock(features * 4, features * 2)
        self.decode_layer1 = StandardBlock(features * 2, features)

        self.out_layer = nn.Sequential(
            nn.Conv2d(features, out_features, kernel_size=1, padding=0, stride=1),
            nn.Sigmoid()
        )

        self.correlation_module = Correlation()
        
        self.weight_layer = nn.Sequential(
            nn.Conv2d(5, 5 // factor, kernel_size=1, padding=0, stride=1),  
            nn.ReLU(),
            nn.Conv2d(5 // factor, 5, kernel_size=1, padding=0, stride=1),
            nn.Sigmoid()
        )

    def forward(self, x, inference=False):
        enc1 = self.encode_layer1(x)
        output1 = self.pool(enc1)

        enc2 = self.encode_layer2(output1)
        output2 = self.pool(enc2)

        enc3 = self.encode_layer3(output2)
        output3 = self.pool(enc3)

        enc4 = self.encode_layer4(output3)
        output4 = self.pool(enc4)

        bottleneck = self.encode_decode_layer(output4)

        dec4 = self.upconv4(bottleneck)
        dec4 = torch.cat((dec4, enc4), dim=1)
        dec4 = self.decode_layer4(dec4)

        dec3 = self.upconv3(dec4)
        dec3 = torch.cat((dec3, enc3), dim=1)
        dec3 = self.decode_layer3(dec3)

        dec2 = self.upconv2(dec3)
        dec2 = torch.cat((dec2, enc2), dim=1)
        dec2 = self.decode_layer2(dec2)

        dec1 = self.upconv1(dec2)
        dec1 = torch.cat((dec1, enc1), dim=1)
        dec1 = self.decode_layer1(dec1)

        out = self.out_layer(dec1)
        
        if not inference:  # 如果非推理模式，执行以下计算
            cor1 = self.correlation_module(output1)
            cor2 = self.correlation_module(output2)
            cor3 = self.correlation_module(output3)
            cor4 = self.correlation_module(output4)
            cor5 = self.correlation_module(bottleneck)
            cor_scores = torch.stack([cor1, cor2, cor3, cor4, cor5], dim=0)
            cor_scores = cor_scores.unsqueeze(-1).unsqueeze(-1).unsqueeze(0)

            weight_params= self.weight_layer(cor_scores)
            cor = torch.sum(weight_params * cor_scores, dim=1)
            
            return out, cor, cor1, cor2, cor3, cor4, cor5  # 在非推理模式返回相应计算结果

        return out  # 在推理模式下，只返回 out