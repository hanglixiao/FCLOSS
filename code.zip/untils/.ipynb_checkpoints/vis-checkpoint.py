import torch
import numpy as np
import matplotlib.pyplot as plt
import cv2
from torch.nn import Module

def preprocess_image(image_path):
    """
    图像预处理：读取图像，归一化，调整维度
    """
    img = cv2.imread(image_path, cv2.IMREAD_COLOR)  # 读取彩色图像
    img = cv2.resize(img, (256, 256))  # 调整图像大小
    img = np.float32(img) / 255.0  # 归一化
    img = np.transpose(img, (2, 0, 1))  # 调整维度为 [C, H, W]
    img = np.expand_dims(img, 0)  # 增加 batch 维度
    input_tensor = torch.from_numpy(img).float()  # 转为 PyTorch 张量
    return input_tensor

def extract_feature_maps(model, input_tensor, target_layer):
    """
    提取指定层的特征图
    """
    feature_maps = []

    def hook(module, input, output):
        feature_maps.append(output)

    hook_handle = target_layer.register_forward_hook(hook)  # 注册前向钩子
    with torch.no_grad():  # 禁用梯度计算
        model(input_tensor)
    hook_handle.remove()  # 移除钩子
    return feature_maps[0]

def plot_feature_maps(feature_maps, save_path='feature_maps.svg', num_cols=8):
    """
    可视化特征图
    """
    feature_maps = feature_maps.squeeze(0).cpu().numpy()  # 去除 batch 维度
    num_channels, height, width = feature_maps.shape
    num_rows = int(np.ceil(num_channels / num_cols))  # 确定行数
    figsize = (num_cols * 5, num_rows * 5)  # 设置画布大小

    fig, axes = plt.subplots(num_rows, num_cols, figsize=figsize)

    for i in range(num_channels):
        row, col = divmod(i, num_cols)
        ax = axes[row, col] if num_rows > 1 else axes[col]
        ax.imshow(feature_maps[i], cmap='viridis')  # 绘制特征图
        ax.axis('off')

    plt.tight_layout()
    plt.savefig(save_path)
    plt.show()

def load_model(model_class, model_path, input_channels, output_channels, base_filters):
    """
    加载模型权重
    """
    model = model_class(input_channels, output_channels, base_filters)
    model.load_state_dict(torch.load(model_path, map_location='cpu'))
    model.eval()  # 设置为评估模式
    return model

def process_image_with_model(image_path, model, target_layer, save_path='feature_maps.svg'):
    """
    图像处理及特征图提取与可视化
    """
    input_tensor = preprocess_image(image_path)  # 图像预处理
    feature_maps = extract_feature_maps(model, input_tensor, target_layer)  # 提取特征图
    plot_feature_maps(feature_maps, save_path)  # 可视化特征图
